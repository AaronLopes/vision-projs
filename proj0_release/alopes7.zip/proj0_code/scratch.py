import torch

v = torch.tensor([1, 2, 3])
print(v[0])


# v_t = torch.tensor([])
# for t in v:
