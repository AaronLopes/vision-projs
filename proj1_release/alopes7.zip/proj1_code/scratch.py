from numpy import dstack, kaiser
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data as data
import matplotlib.pyplot as plt
import student_code
from utils import load_image, save_image

"""
image1 = load_image(
    '/Users/AaronLopes/Desktop/cs4476/proj1_release/proj1_code/data/1a_dog.bmp')
image2 = load_image(
    '/Users/AaronLopes/Desktop/cs4476/proj1_release/proj1_code/data/1b_cat.bmp')

m = image1.shape[0]
n = image1.shape[1]
c = image1.shape[2]

print('image1 shape: \n', image1.shape)
print('image1 first channel: \n', image1[:, :, 0])
"""

k = 11

print(k // 2)
